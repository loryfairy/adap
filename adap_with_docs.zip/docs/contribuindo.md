# Como Contribuir para o Adap

Este projeto valoriza contribuições diversas! Você pode:

- Corrigir erros ou melhorar a documentação
- Sugerir ou implementar módulos mais eficientes
- Ajudar na tradução e acessibilidade

Veja também: [CONTRIBUTING.md](../CONTRIBUTING.md)