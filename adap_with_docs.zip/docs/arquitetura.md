# Arquitetura do Adap

O sistema é composto por três camadas principais:

1. **Percepção** – coleta de contexto (usuário, ambiente, energia)
2. **Adaptação** – decisão sobre o uso de módulos otimizados
3. **Execução** – resposta leve, eficiente e focada na necessidade

*Em breve: diagrama SVG da arquitetura em /assets*