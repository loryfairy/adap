# Eficiência e Sustentabilidade no Adap

O Adap adota estratégias como:

- Redução do uso de CPU/RAM com compressão e fallback adaptativo
- Execução local contextual, reduzindo chamadas à nuvem
- Modularidade para se adequar a hardwares limitados