# Bem-vindo ao Adap

O **Adap** é uma proposta de arquitetura modular de Inteligência Artificial com foco em:

- Eficiência Energética
- Sustentabilidade Computacional
- Adaptabilidade Contextual

Explore os documentos abaixo para entender como o Adap funciona e como você pode contribuir.

## Seções

- [Arquitetura](arquitetura.md)
- [Eficiência & Sustentabilidade](eficiencia.md)
- [Contribuindo](contribuindo.md)