
# Arquitetura Adap + IoT

Este diagrama representa a integração entre o Adap 2.0 e dispositivos IoT em ambientes sensíveis, como hospitais, casas inteligentes ou escolas inclusivas.

A arquitetura propõe:

- Uso de sensores IoT para captar sinais físicos e emocionais (voz, movimento, batimentos).
- Camada Adap filtrando ruídos e interpretando intenções com empatia e segurança.
- Encaminhamento para um sistema de IA principal que executa ações práticas ou recomendações.
- Priorização da resposta humana quando necessário (como chamadas de apoio ou alertas).

![Arquitetura Adap + IoT](docs_adap_iot.png)
