# Guia de Contribuição

1. Crie uma *issue* com sugestão ou problema.
2. Faça um *fork*.
3. Crie um *branch*.
4. Envie um *pull request* com um resumo claro.
