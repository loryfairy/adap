# Código de Conduta

Este projeto adota o Código de Conduta do Contributor Covenant. Esperamos respeito mútuo e colaboração ética.

Mais em: https://www.contributor-covenant.org/pt-br/version/2/1/code_of_conduct/
