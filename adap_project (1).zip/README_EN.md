# Adap: AI with Soul and Awareness

A complementary architecture for AI systems focused on computational efficiency, empathy, and emotional safety.

## 🔍 Overview

**Adap** is an adaptive layer that preprocesses user input to reduce irrelevant data, detect emotions, and respect attention and intent.

## 📂 Files

- `docs/Conceito_Adap_Detalhado.md` — Full concept (Portuguese)
- `docs/Adap_Concept_English.md` — Full concept (English)

## 💡 Key Features

- 🎙️ **Voice Semaphore**: Listens completely, filters hesitation and interruptions.
- 🖥️ **Focus Manager**: Tracks screen attention to reduce unnecessary processing.
- 💡 **Mood Ring**: Displays how the AI interprets emotional state in real-time.

## 🌱 Inspired by *Philia*

Rooted in Aristotle’s philosophy, Adap embraces ethical friendship:
- Reciprocity and well-being
- Transparent and trustworthy interactions
- Clear emotional boundaries

## 🤝 Contribute

We welcome collaborators! Special thanks to Meta AI, DeepSeek, Gemini, and ChatGPT for insights.

---

© 2025 Lorena de Medeiros – MIT License
