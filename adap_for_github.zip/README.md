# Adap

IA que sente, se adapta e consome menos.

## Sobre

Adap é uma arquitetura modular de Inteligência Artificial voltada para eficiência energética, adaptabilidade contextual e sustentabilidade computacional.

## Documentação

Veja mais em [docs/Conceito_Adap_Detalhado.md](docs/Conceito_Adap_Detalhado.md)
