# Código de Conduta

Este projeto adota o Contributor Covenant. Esperamos colaboração respeitosa e inclusiva.
