# Conceito Técnico – Adap

O Adap é uma arquitetura modular de IA com foco em eficiência, sustentabilidade e adaptabilidade.

## Módulos

- Percepção
- Adaptação
- Execução
